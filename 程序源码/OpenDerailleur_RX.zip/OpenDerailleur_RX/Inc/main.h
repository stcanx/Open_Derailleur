/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

#define LED_G_Pin GPIO_PIN_0
#define LED_G_GPIO_Port GPIOF
#define LED_R_Pin GPIO_PIN_1
#define LED_R_GPIO_Port GPIOF
#define CE_Pin GPIO_PIN_0
#define CE_GPIO_Port GPIOA
#define CSN_Pin GPIO_PIN_1
#define CSN_GPIO_Port GPIOA
#define IRQ_Pin GPIO_PIN_2
#define IRQ_GPIO_Port GPIOA
#define IRQ_EXTI_IRQn EXTI2_3_IRQn
#define STDBY_Pin GPIO_PIN_3
#define STDBY_GPIO_Port GPIOA
#define KEY_ADD_Pin GPIO_PIN_0
#define KEY_ADD_GPIO_Port GPIOB
#define KEY_DEC_Pin GPIO_PIN_1
#define KEY_DEC_GPIO_Port GPIOB
#define KEY_MENU_Pin GPIO_PIN_8
#define KEY_MENU_GPIO_Port GPIOA
#define SCL_Pin GPIO_PIN_9
#define SCL_GPIO_Port GPIOA
#define SDA_Pin GPIO_PIN_10
#define SDA_GPIO_Port GPIOA
#define IN1_Pin GPIO_PIN_11
#define IN1_GPIO_Port GPIOA
#define IN1_EXTI_IRQn EXTI4_15_IRQn
#define IN2_Pin GPIO_PIN_12
#define IN2_GPIO_Port GPIOA
#define IN2_EXTI_IRQn EXTI4_15_IRQn
#define ADC_ENABLE_Pin GPIO_PIN_15
#define ADC_ENABLE_GPIO_Port GPIOA
#define CHRG_Pin GPIO_PIN_3
#define CHRG_GPIO_Port GPIOB
#define MOTO_Pin GPIO_PIN_4
#define MOTO_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

extern volatile uint16_t task;
extern uint8_t RxCount,RxBuff;
extern volatile uint16_t moto_time,adc_time,led_blink_time,user_time;

typedef struct{
	uint16_t 	Voltage;						//�󲦵�ѹֵ
	uint8_t 	Gear;								//�ܹ��ĵ�λ����
	uint16_t 	Gear_Tab[16];				//��λ��ӦPWMֵ					
	uint8_t 	Now_Gear;						//��ǰ��λֵ
	uint8_t   Set_Gear;						//Ŀ���趨��λ
	uint8_t		Delay_Gear;					//�����λ�л�֮�����ʱ
	uint8_t 	address[5];					//NRFģ���ͨ�ŵ�ַ
	uint8_t 	ch[2];							//NRFģ�������Ƶ��
}Dera_typ;

#define GEAR_NUMBER     10						//����Ƭ��
#define GEAR_MIN				 0						//��С��λ���
#define GEAR_MAX    (GEAR_NUMBER-1) 	//���λ���

#define SERVO_PULSE_MAX	 3500					//������������ ��λ��us��		���ʹ�ò�ͬ�Ķ�����ܴ˴���Ҫ�޸�
#define SERVO_PULSE_MIN	 600					//�������С���� ��λ��us��

#define SAVE_DATA_ADDRESS   		0x08007C00UL   	//���������ַ����F030K6��32KB��flash���1KB 

#define TASK_KEY_MENU_DOG				0x1				//KEY_menu �̰�
#define TASK_KEY_MENU_PRESS			0x2				//KEY_menu ����
#define TASK_KEY_ADD_DOG				0x4				//KEY_add	�̰� 
#define TASK_KEY_ADD_PRESS			0x8				//KEY_add ����
#define TASK_KEY_DEC_DOG				0x10			//KEY_dec �̰�
#define TASK_KEY_DEC_PRESS			0x20			//KEY_dec ����
#define TASK_ADXL345_SLEEP			0x40			//ADXL_345 ���ߴ���
#define TASK_NRF24L01_RX				0x80			//NRF24L01 �յ�����
#define TASK_NRF24L01_TX				0x100			//NRF24L01 ��������
#define TASK_NRF24L01_TX_ERR		0x200			//NRF24L01 ����δ���
#define TASK_ADXL345_ACTIVITY		0x400			//ADXL345 �˶��ж�
#define TASK_ADXL345_INACTIVITY 0x800			//ADXL345 ��ֹ�ж�
#define TASK_MOTO_CONTROL				0x1000		//�������
#define TASK_ADC_READ						0x2000		//��ص�ѹ�ɼ�
void SystemClock_Config(void);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
