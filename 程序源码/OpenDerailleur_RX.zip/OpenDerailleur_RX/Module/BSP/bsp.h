/*-----------------------------------------------------------------------
����Ӳ��ʵ��Ľӿڣ�����
	LED							��ɫ ��ɫ
	ADC							��ѹ��ȡ
	KEY							MENU/ADD/DEC ����						IO������,���°����͵�ƽ
	PWM_OUT					PWM�ź����
	MOTO_CONTROL		���ʹ���ź�



------------------------------------------------------------------------*/
#ifndef __BSP_H_
#define __BSP_H_

#include "main.h"
#include "stm32f0xx_hal.h"
#include "adc.h"
#include "stm32f0xx_hal.h"
#include "usart.h"
#include "gpio.h"
#include "spi.h"
#include "tim.h"
#include "nrf24.h"

#define LED_G_ON			HAL_GPIO_WritePin(LED_G_GPIO_Port,LED_G_Pin,GPIO_PIN_SET);
#define LED_G_OFF			HAL_GPIO_WritePin(LED_G_GPIO_Port,LED_G_Pin,GPIO_PIN_RESET);
#define LED_G_TOGGLE	HAL_GPIO_TogglePin(LED_G_GPIO_Port,LED_G_Pin);

#define LED_R_ON			HAL_GPIO_WritePin(LED_R_GPIO_Port,LED_R_Pin,GPIO_PIN_SET);
#define LED_R_OFF			HAL_GPIO_WritePin(LED_R_GPIO_Port,LED_R_Pin,GPIO_PIN_RESET);
#define LED_R_TOGGLE	HAL_GPIO_TogglePin(LED_R_GPIO_Port,LED_R_Pin);

#define MOTO_ON	 			HAL_GPIO_WritePin(MOTO_GPIO_Port,MOTO_Pin,GPIO_PIN_SET);
#define MOTO_OFF 			HAL_GPIO_WritePin(MOTO_GPIO_Port,MOTO_Pin,GPIO_PIN_RESET);

#define KEY1_READ			HAL_GPIO_ReadPin(KEY_ADD_GPIO_Port,KEY_ADD_Pin)
#define KEY2_READ			HAL_GPIO_ReadPin(KEY_DEC_GPIO_Port,KEY_DEC_Pin)
#define KEY3_READ			HAL_GPIO_ReadPin(KEY_MENU_GPIO_Port,KEY_MENU_Pin)




uint16_t Get_Battery(Dera_typ *data);
void Battery_Bilnk(Dera_typ *data);

void Get_Key(void);
void Power_Down(void);
void Moto_Contrl(Dera_typ *data);
void Set_Gear_Value(Dera_typ *data);

void Dera_Read_Flah(Dera_typ *data);
void Dera_Save_Flash(Dera_typ *data);

void Derailleur_Init(Dera_typ *data);
void Derailleur_Defult(Dera_typ *data);

void Connect_Loop(Dera_typ *data);
#endif
