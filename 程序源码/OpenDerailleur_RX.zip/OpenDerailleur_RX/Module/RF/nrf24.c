#include "nrf24.h"

uint8_t sta;


unsigned char const TX_ADDRESS[TX_ADR_WIDTH] = {0x13,0x14,0x52,0x05,0x20};  // 定义一个静态发送地址
unsigned char const RX_ADDRESS[RX_ADR_WIDTH] = {0x13,0x14,0x52,0x05,0x20};  // 定义一个静态发送地址
unsigned char const BASE_ADDRES[TX_ADR_WIDTH] = {'o','p','d','i','2'};

uint8_t RX_BUF[TX_PLOAD_WIDTH];		 //接收缓存
uint8_t TX_BUF[TX_PLOAD_WIDTH];		 //发送缓存

uint8_t SPI_NWRITE_REG(uint8_t reg, uint8_t value);
uint8_t SPI_Read(uint8_t reg);
/**************************************************/

HAL_StatusTypeDef NRF_RX_Init(void)
{
	uint8_t read_data;
	CE_L        // 待机
	SPI_Write_Buf(NWRITE_REG + TX_ADDR, (unsigned char*)BASE_ADDRES, TX_ADR_WIDTH);     // 写入发送地址
	SPI_Write_Buf(NWRITE_REG + RX_ADDR_P0,(unsigned char*)BASE_ADDRES, RX_ADR_WIDTH);  // 为了应答接收设备，接收通道0地址和发送地址相同		
	SPI_NWRITE_REG(NWRITE_REG + EN_AA, 0x01);       // 使能接收通道0自动应答
	SPI_NWRITE_REG(NWRITE_REG + EN_RXADDR, 0x01);   // 使能接收通道0
	SPI_NWRITE_REG(NWRITE_REG + SETUP_RETR, 0x1F);  // 自动重发延时等待500us，自动重发10次
	SPI_NWRITE_REG(NWRITE_REG + RF_CH, 2);          // 先默认为0
	SPI_NWRITE_REG(NWRITE_REG + RF_SETUP, 0x07);    // 数据传输率1Mbps，发射功率0dBm，低噪声放大器增益
	
	SPI_NWRITE_REG(NWRITE_REG + CONFIG, 0x0F);   		 // IRQ收发完成中断开启,16位CRC,接收
	SPI_NWRITE_REG(FLUSH_TX,0xff);
	SPI_NWRITE_REG(FLUSH_RX,0xff);
	SPI_RW(0x50);																			//开启隐藏功能 ACK带包传送
	SPI_RW(0x73);
	SPI_NWRITE_REG(NWRITE_REG+DYNPD,0x01);						//P0通道 启用动态载荷长度				
	SPI_NWRITE_REG(NWRITE_REG+FEATURE,0x06);					//启用动态载荷长度 允许载荷带ACK
	
	read_data = SPI_Read(CONFIG);	
	if(read_data == 0x0F)
		return HAL_OK;
	else
		return HAL_ERROR;
}



HAL_StatusTypeDef NRF_TX_Init(void)
{
	uint8_t read_data;	
	CE_L        // 待机
	
	SPI_Write_Buf(NWRITE_REG + TX_ADDR, (unsigned char*)BASE_ADDRES, TX_ADR_WIDTH);     // 写入发送地址
	SPI_Write_Buf(NWRITE_REG + RX_ADDR_P0,(unsigned char*)BASE_ADDRES, RX_ADR_WIDTH);  // 为了应答接收设备，接收通道0地址和发送地址相同	
	SPI_NWRITE_REG(NWRITE_REG + EN_AA, 0x01);       // 使能接收通道0自动应答
	SPI_NWRITE_REG(NWRITE_REG + EN_RXADDR, 0x01);   // 使能接收通道0
	SPI_NWRITE_REG(NWRITE_REG + SETUP_RETR, 0x1F);  // 自动重发延时等待500us，自动重发10次
	SPI_NWRITE_REG(NWRITE_REG + RF_CH, 2);          // 先默认为0
	SPI_NWRITE_REG(NWRITE_REG + RF_SETUP, 0x07);    // 数据传输率1Mbps，发射功率0dBm，低噪声放大器增益
	
	SPI_NWRITE_REG(NWRITE_REG + CONFIG, 0x0E);   		 // IRQ收发完成中断开启,16位CRC,发送
	SPI_NWRITE_REG(FLUSH_TX,0xff);
	SPI_NWRITE_REG(FLUSH_RX,0xff);
	SPI_RW(0x50);																			//开启隐藏功能 ACK带包传送
	SPI_RW(0x73);
	SPI_NWRITE_REG(NWRITE_REG+DYNPD,0x01);						//P0通道 启用动态载荷长度				
	SPI_NWRITE_REG(NWRITE_REG+FEATURE,0x06);					//启用动态载荷长度 允许载荷带ACK
	
	read_data = SPI_Read(CONFIG);	
	if(read_data == 0x0E)
		return HAL_OK;
	else
		return HAL_ERROR;	
}

void NRF_Tx_Buff(uint8_t *pBuf, uint8_t Len) 	//发送数据包，用于发送模式2/4
{
	CE_L
	SPI_Write_Buf(NWRITE_REG + RX_ADDR_P0, (unsigned char*)TX_ADDRESS, TX_ADR_WIDTH); // 装载接收端地址
	SPI_Write_Buf(WR_TX_PLOAD, pBuf, Len); 			 // 装载数据
	CE_H
}

void NRF_Tx_Ack_Buff(uint8_t *pBuf, uint8_t Len) //发送数据包，接收模式2
{
	CE_L
	SPI_Write_Buf(W_ACK_PAYLOAD, pBuf, Len);
	CE_H
}

void NRF_Set_Address(uint8_t *pbuf,uint8_t Len)
{
	CE_L
	SPI_Write_Buf(NWRITE_REG + TX_ADDR, (unsigned char*)pbuf, Len);     // 写入发送地址
	SPI_Write_Buf(NWRITE_REG + RX_ADDR_P0,(unsigned char*)pbuf, Len);  	// 为了应答接收设备，接收通道0地址和发送地址相同	
}

void NRF_Set_CH(uint8_t CH)
{
	CE_L
	SPI_NWRITE_REG(NWRITE_REG + RF_CH,CH);          
}

void NRF_IRQ_Handler(void)
{
	uint8_t Length;
	CE_L
	sta = SPI_Read(NREAD_REG+STATUS);							//获取状态寄存器
	SPI_NWRITE_REG(NWRITE_REG + STATUS,sta);			//清除中断
	if(sta & 0x40)
	{
		Length = SPI_Read(NREAD_REG+R_RX_PL_WID);		//读取数据包的长度
		if(Length < 33)
		{
			SPI_Read_Buf(RD_RX_PLOAD,RX_BUF,Length);	//读出数据
			SET_BIT(task,TASK_NRF24L01_RX);						//标记NRF24L01_RX任务，让main轮询处理
			SPI_NWRITE_REG(FLUSH_RX,0xFF);
		}	
		else
		{
			SPI_NWRITE_REG(FLUSH_RX,0xFF);
		}
	}
	if(sta&0x20)																	//发送完成标志
	{
		SPI_NWRITE_REG(FLUSH_TX,0xff);
		SET_BIT(task,TASK_NRF24L01_TX);
	}
	if(sta&0x10)																	//达到最大重发次数中断														
	{
		SPI_NWRITE_REG(FLUSH_TX,0xff);
		SET_BIT(task,TASK_NRF24L01_TX_ERR);		
	}
	printf("sta is %x\r\n",sta);
}

void NRF_Stop(void)
{
	uint8_t reg;
	CE_L
	reg = SPI_Read(NREAD_REG+CONFIG);
	reg = reg & 0xFD;																 //CONFIG.1清零 进入STOP模式
	SPI_NWRITE_REG(NWRITE_REG + CONFIG, reg);   	
}
void NRF_WakeUp(void)
{
//	uint8_t reg;
	CE_L
	//reg = SPI_Read(NREAD_REG+CONFIG);
	//reg = reg | 0x02;																 //CONFIG.1置一 退出STOP模式
	//SPI_NWRITE_REG(NWRITE_REG + CONFIG, reg);   	
	SPI_NWRITE_REG(NWRITE_REG + CONFIG, 0x0F);  	
}

/*-
	NRF24L01指令解析函数
根据接收到的不同命令做不同的操作，装载不同的回传数据
-*/
void NRF_Command(Dera_typ *data) 
{
	static uint8_t old_pid;					//保存旧包 防止粘包存在
	printf("主机-> 从机 RX_BUF[] = %d %d %d %d\r\n",RX_BUF[0],RX_BUF[1],RX_BUF[2],RX_BUF[3]);	
	
	if(RX_BUF[0] == 0xFF)									//【握手的信息交换】
	{	
		printf("装载握手回传数据包\r\n");
		TX_BUF[0] = 0xFF;										//装载回传包	握手数据
		TX_BUF[1] = data->address[0];
		TX_BUF[2] = data->address[1];
		TX_BUF[3] = data->address[2];
		TX_BUF[4] = data->address[3];
		TX_BUF[5] = data->address[4];
		TX_BUF[6] = data->ch[0];
		TX_BUF[7] = data->ch[1];
		
		NRF_Tx_Ack_Buff(TX_BUF,8);						//NRF模块装载应答包
	}
	
	else if(RX_BUF[0] == 0xFE)						//【通信更新的确认命令】握手最后一步
	{
		TX_BUF[0] = 0xFE;										//回传命令头
		
		NRF_Set_Address(data->address,5);
		NRF_Set_CH(data->ch[0]);
		
		NRF_Tx_Ack_Buff(TX_BUF,4);						//NRF模块装载应答包
		//SET_BIT(task,TASK_KEY_MENU_PRESS);		//软件触发实现长按MENU键效果 退出调试模式
		//Dera_Save_Flash(data);
		NRF_Status_Printf();
		printf("推出握手命令\r\n");
	}
	else if(RX_BUF[0] == 0x01)						//【常规的通信】
	{
		TX_BUF[0] = 0x01;										//装载回传报头		
		TX_BUF[1] = data->Voltage;					//当前电压			每10S更新一次
		TX_BUF[2] = data->Gear;							//总共档位
		TX_BUF[3] = data->Now_Gear;					//当前档位	
		
		NRF_Tx_Ack_Buff(TX_BUF,4);
		
		if(RX_BUF[1] == 0x01 && old_pid != RX_BUF[3])		//档位++命令
			if(data->Set_Gear < GEAR_MAX)data->Set_Gear++;
																		
		if(RX_BUF[1] == 0x02 && old_pid != RX_BUF[3])		//挡位--
			if(data->Set_Gear > GEAR_MIN)data->Set_Gear--;

		if(RX_BUF[1] == 0x03 && old_pid != RX_BUF[3])		//冲刺
			data->Set_Gear = GEAR_MIN;

		if(RX_BUF[1] == 0x04 && old_pid != RX_BUF[3])		//爬坡
			data->Set_Gear = GEAR_MAX;
	
		old_pid = RX_BUF[3];														//保存上次通信的旧包
		SET_BIT(task,TASK_MOTO_CONTROL);														

	}
	else
		;
	
	//NRF_Tx_Ack_Buff(TX_BUF,4);						//NRF模块装载应答包
} 
void NRF_Status_Printf(void)
{ 
	uint8_t status,status_cache[5];
	status = SPI_Read(CONFIG);					
	printf("CONFIG = %X \r\n",status);	
	status = SPI_Read(RF_SETUP);					//读取状态
	printf("RF_SETUP = %X \r\n",status);	
	
	status = SPI_Read(SETUP_RETR);					//读取状态
	printf("SETUP_RETR = %X \r\n",status);	
	
	status = SPI_Read(RF_CH);					//读取状态
	printf("RF_CH = %X \r\n",status);
	status = SPI_Read(EN_RXADDR);					//读取状态
	printf("EN_RXADDR = %X \r\n",status);
	status = SPI_Read(EN_AA);					//读取状态
	printf("EN_AA = %X \r\n",status);
	status = SPI_Read(SETUP_AW);					//读取状态
	printf("SETUP_AW = %X \r\n",status);	
	status = SPI_Read(RX_PW_P0);					//读取状态
	printf("RX_PW_P0 = %X \r\n",status);		
	
	SPI_Read_Buf(NREAD_REG+TX_ADDR,status_cache,5);
	printf("TX_addr = %d %d %d %d %d \r\n",status_cache[0],status_cache[1],status_cache[2],status_cache[3],status_cache[4]);
	SPI_Read_Buf(NREAD_REG+RX_ADDR_P0,status_cache,5);
	printf("RX addr = %d %d %d %d %d \r\n",status_cache[0],status_cache[1],status_cache[2],status_cache[3],status_cache[4]);
	printf("\r\n\r\n");  		

}

/*-
	NRF模块的低功耗接收控制
			原理：间歇性休眠和运行
-*/
void NRF_LowPowerRx(Dera_typ *data)
{
	if(READ_BIT(task,TASK_NRF24L01_RX))
	{
		CLEAR_BIT(task,TASK_NRF24L01_RX);
		NRF_Command(data);
	}
	else
	{	
		NRF_Stop();					//NRF模块低功耗模式 CPU进入睡眠模式，CPU会被systick中断唤醒
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI); 	
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);
//		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);
//		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI); 

		NRF_WakeUp();														//在CH[0]频段等待3ms接收数据
		NRF_Set_CH(data->ch[0]);
		CE_H
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  	
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI); 
//		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  		
		
		NRF_Set_CH(data->ch[1]);								//在CH[1]频段等待3ms接收数据
		CE_H
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  
//		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);  		
		NRF_Stop();
	}
}
/**************************************************/

/**************************************************
函数：SPI_RW()

描述：
    根据SPI协议，写一字节数据到nRF24L01，同时从nRF24L01
	读出一字节
**************************************************/
uint8_t SPI_RW(uint8_t input)
{
		uint8_t out;
		HAL_SPI_TransmitReceive(&hspi1,&input,&out,1,0xF0);
    return(out);           	// 返回读出的一字节
}
/**************************************************/

/**************************************************
函数：SPI_RW_Reg()

描述：
    写数据value到reg寄存器
**************************************************/
uint8_t SPI_NWRITE_REG(uint8_t reg, uint8_t value)
{
	uint8_t status;
  	CSN_L                   // CSN置低，开始传输数据
  	status = SPI_RW(reg);      // 选择寄存器，同时返回状态字
  	SPI_RW(value);             // 然后写数据到该寄存器
  	CSN_H                   // CSN拉高，结束数据传输
  	return(status);            // 返回状态寄存器
}
/**************************************************/

/**************************************************
函数：SPI_Read()

描述：
    从reg寄存器读一字节
**************************************************/
uint8_t SPI_Read(uint8_t reg)
{
	uint8_t reg_val;
  	CSN_L                    // CSN置低，开始传输数据
  	SPI_RW(reg);                // 选择寄存器
  	reg_val = SPI_RW(0);        // 然后从该寄存器读数据
  	CSN_H                    // CSN拉高，结束数据传输
  	return(reg_val);            // 返回寄存器数据
}
/**************************************************/

/**************************************************
函数：SPI_Read_Buf()

描述：
    从reg寄存器读出uint8_ts个字节，通常用来读取接收通道
	数据或接收/发送地址
**************************************************/
uint8_t SPI_Read_Buf(uint8_t reg, uint8_t * pBuf, uint8_t uint8_ts)
{
	uint8_t status, i;
  	CSN_L                    // CSN置低，开始传输数据
  	status = SPI_RW(reg);       // 选择寄存器，同时返回状态字
  	for(i=0; i<uint8_ts; i++)
    	pBuf[i] = SPI_RW(0);    // 逐个字节从nRF24L01读出
  	CSN_H                    // CSN拉高，结束数据传输
  	return(status);             // 返回状态寄存器
}
/**************************************************/

/**************************************************
函数：SPI_Write_Buf()

描述：
    把pBuf缓存中的数据写入到nRF24L01，通常用来写入发
	射通道数据或接收/发送地址
**************************************************/
uint8_t SPI_Write_Buf(uint8_t reg, uint8_t * pBuf, uint8_t uint8_ts)
{
	uint8_t status, i;
	CSN_L                    // CSN置低，开始传输数据
	status = SPI_RW(reg);       // 选择寄存器，同时返回状态字
	for(i=0; i<uint8_ts; i++)
  SPI_RW(pBuf[i]);        // 逐个字节写入nRF24L01
	CSN_H                    // CSN拉高，结束数据传输
	return(status);             // 返回状态寄存器
}
/**************************************************/






