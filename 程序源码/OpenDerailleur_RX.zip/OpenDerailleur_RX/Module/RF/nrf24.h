#ifndef __NRF24_H_
#define __NRF24_H_

#include "main.h"
#include "stm32f0xx_hal.h"
#include "spi.h"
#include "stdio.h"
#include "bsp.h"

// SPI(nRF24L01) commands
#define NREAD_REG    0x00  //读寄存器指令
#define NWRITE_REG   0x20  //写寄存器指令
#define R_RX_PL_WID 0x60  //读接收到的数据长度
#define RD_RX_PLOAD 0x61  //读接收数据指令
#define WR_TX_PLOAD 0xA0  //写待发送数据指令
#define W_ACK_PAYLOAD	0xA8  //写ACK数据指令，用于接收模式
#define FLUSH_TX    0xE1  //冲洗发送FIFO指令
#define FLUSH_RX    0xE2  //冲洗接收FIFO指令
#define REUSE_TX_PL 0xE3  //重复装载数据指令
#define NOP         0xFF  //空指令，用于读出状态字

//寄存器地址
#define CONFIG      0x00  //配置寄存器
#define EN_AA       0x01  //自动应答，禁止自动应答后可以与2401通讯
#define EN_RXADDR   0x02  //接收地址允许
#define SETUP_AW    0x03  //设置地址宽度
#define SETUP_RETR  0x04  //自动重发
#define RF_CH       0x05  //射频通道
#define RF_SETUP    0x06  //射频寄存器
#define STATUS      0x07  //状态寄存器
#define OBSERVE_TX  0x08  //发送检测寄存器
#define CD          0x09  //地址检查
#define RX_ADDR_P0  0x0A  //数据通道0接收地址，最大长度5个字节，先写低字节，所有字节数量由SETUP_AW设定
#define RX_ADDR_P1  0x0B  //数据通道1接收地址，最大长度5个字节，先写低字节，所有字节数量由SETUP_AW设定
#define RX_ADDR_P2  0x0C  //数据通道2接收地址，最低字节可设定，高字节部分必须与RX_ADDR_P1[39:8]相等
#define RX_ADDR_P3  0x0D  //数据通道3接收地址，最低字节可设定，高字节部分必须与RX_ADDR_P1[39:8]相等
#define RX_ADDR_P4  0x0E  //数据通道4接收地址，最低字节可设定，高字节部分必须与RX_ADDR_P1[39:8]相等
#define RX_ADDR_P5  0x0F  //数据通道5接收地址，最低字节可设定，高字节部分必须与RX_ADDR_P1[39:8]相等
#define TX_ADDR     0x10  //发送地址
#define RX_PW_P0    0x11  //通道0接收数据长度
#define RX_PW_P1    0x12  //通道1接收数据长度
#define RX_PW_P2    0x13  //通道2接收数据长度
#define RX_PW_P3    0x14  //通道3接收数据长度
#define RX_PW_P4    0x15  //通道4接收数据长度
#define RX_PW_P5    0x16  //通道5接收数据长度
#define FIFO_STATUS 0x17  //FIFO状态寄存器

#define DYNPD 			0x1C
#define FEATURE			0x1D

#define TX_ADR_WIDTH   5  // 5字节宽度的发送地址
#define RX_ADR_WIDTH   5  // 5字节宽度的接收地址

#define TX_PLOAD_WIDTH 32  // 数据通道有效数据宽度
#define RX_PLOAD_WIDTH 32  // 数据通道有效数据宽度

#define CSN_L HAL_GPIO_WritePin(CSN_GPIO_Port,CSN_Pin,GPIO_PIN_RESET);
#define CSN_H	HAL_GPIO_WritePin(CSN_GPIO_Port,CSN_Pin,GPIO_PIN_SET);

#define CE_L HAL_GPIO_WritePin(CE_GPIO_Port,CE_Pin,GPIO_PIN_RESET);	
#define CE_H HAL_GPIO_WritePin(CE_GPIO_Port,CE_Pin,GPIO_PIN_SET);	

#define IRQ_R HAL_GPIO_ReadPin(IRQ_GPIO_Port,IRQ_Pin)
		
	

extern uint8_t const TX_ADDRESS[TX_ADR_WIDTH];
extern uint8_t const RX_ADDRESS[RX_ADR_WIDTH];
extern uint8_t const BASE_ADDRES[TX_ADR_WIDTH];
extern uint8_t  RX_BUF[RX_PLOAD_WIDTH];		 //接收缓存
extern uint8_t  TX_BUF[TX_PLOAD_WIDTH];		 //发送缓存



uint8_t SPI_RW(uint8_t uint8_t);		//SPI读写函数
uint8_t SPI_Write_Reg(uint8_t reg, uint8_t value);
uint8_t SPI_Read(uint8_t reg);
uint8_t SPI_Read_Buf(uint8_t reg, uint8_t * pBuf, uint8_t uint8_ts);
uint8_t SPI_Write_Buf(uint8_t reg, uint8_t * pBuf, uint8_t uint8_ts);

HAL_StatusTypeDef NRF_RX_Init(void);
HAL_StatusTypeDef NRF_TX_Init(void);
void NRF_Tx_Buff(uint8_t *pBuf, uint8_t Len); 				//发送端发送数据包
void NRF_Tx_Ack_Buff(uint8_t *pBuf, uint8_t Len); 		//接收端装载应答包作ACK回复	RX模式下立即开启接收

void NRF_Set_CH(uint8_t CH);
void NRF_Set_Address(uint8_t *pbuf,uint8_t Len);

void NRF_IRQ_Handler(void);
void NRF_Stop(void);
void NRF_WakeUp(void);
void NRF_Status_Printf(void);

void NRF_Command(Dera_typ *data);						//事务处理函数
void NRF_LowPowerRx(Dera_typ *data);				//低功耗接收函数 间歇开启接收窗口
/*------------------------------------------------------------------------------------
						SPI_RW(0x50);
						SPI_RW(0x73);
						
数据0X73后面的此写命令将激活以下功能
W_ACK_PAYLOAD
R_RX_PL_WID
W_TX_PAYLOAD_NOACK
具有相同数据的新激活命令再次将其禁用，这仅在断电或待机模式下可执行

R_rx_pl_wid功能寄存器最初处于停用状态，写操作有效，只读，导致MISO上的零激活这些寄存器，
使用ACTIVATE命令命令购买数据0x73那么可以像使用nrf24l01中的任何其他寄存器一样使用相同的
命令和数据来访问它们，从而再次停用它们

	printf("开始运行\r\n");
	SPI_NWRITE_REG(NWRITE_REG + CONFIG, 0x0e);		
	Init_24L01(Mode_RX2,40);	
	
	status = SPI_Read(CONFIG);					//读取状态
	printf("CONFIG = %X \r\n",status);	
	status = SPI_Read(RF_SETUP);					//读取状态
	printf("RF_SETUP = %X \r\n",status);	
	
	status = SPI_Read(SETUP_RETR);					//读取状态
	printf("SETUP_RETR = %X \r\n",status);	
	
	status = SPI_Read(RF_CH);					//读取状态
	printf("RF_CH = %X \r\n",status);
	status = SPI_Read(EN_RXADDR);					//读取状态
	printf("EN_RXADDR = %X \r\n",status);
	status = SPI_Read(EN_AA);					//读取状态
	printf("EN_AA = %X \r\n",status);
	status = SPI_Read(SETUP_AW);					//读取状态
	printf("SETUP_AW = %X \r\n",status);	
	status = SPI_Read(RX_PW_P0);					//读取状态
	printf("RX_PW_P0 = %X \r\n",status);		
	printf("\r\n\r\n");  
------------------------------------------------------------------------------------*/
#endif 
